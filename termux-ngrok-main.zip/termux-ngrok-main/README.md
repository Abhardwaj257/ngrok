# termux-ngrok
Run official ngrok in termux 

# Install
```bash
pkg update -y
pkg install git
git clone https://github.com/Yisus7u7/termux-ngrok

cd termux-ngrok
bash install.sh
```

And run : `ngrok`

# Manifest

ES: este repositorio es codigo libre, puedes usarlo sin ningun problema.

EN: this repository is free code, you can use it without any problem.
